import React from 'react';
import { PROBLEM_PILLARS } from '../config/eventData';

export const ProblemSection: React.FC = () => {
  return (
    <section id="about" className="py-16 sm:py-20 bg-white border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-[#005D26]">
            LET'S BE HONEST
          </span>
          <h2 className="text-3xl sm:text-4xl font-sans font-bold tracking-tight text-[#15231A] leading-tight text-balance">
            Good grades matter.{' '}
            <span className="font-editorial italic font-normal text-[#005D26]">
              So does everything else.
            </span>
          </h2>
          <p className="text-base text-[#657168] leading-relaxed">
            University is about balancing exam brilliance with real skills, networks, and opportunities for life after graduation.
          </p>
        </div>

        {/* 3 Distinct Statements */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          {PROBLEM_PILLARS.map((pillar) => (
            <div
              key={pillar.number}
              className="p-6 bg-[#F8F7F0] rounded-2xl border border-neutral-200 hover:border-[#005D26]/40 transition-all hover:shadow-sm"
            >
              <div className="flex items-center justify-between pb-4 mb-4 border-b border-neutral-200">
                <span className="font-mono text-xl font-bold text-[#005D26] tabular-nums">
                  {pillar.number}
                </span>
                <span className="text-[11px] font-semibold uppercase tracking-wider text-[#657168]">
                  Pillar
                </span>
              </div>

              <h3 className="text-lg sm:text-xl font-sans font-bold text-[#15231A] tracking-tight">
                {pillar.title}
              </h3>

              <p className="mt-2.5 text-sm text-[#657168] leading-relaxed">
                {pillar.description}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
