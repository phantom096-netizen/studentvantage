import React from 'react';
import { LEARNING_AREAS } from '../config/eventData';

export const LearningOutcomes: React.FC = () => {
  return (
    <section id="learning" className="py-16 sm:py-20 bg-[#F8F7F0] border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-2xl space-y-3 pb-8">
          <span className="text-xs font-bold uppercase tracking-widest text-[#005D26]">
            WHAT YOU'LL GET
          </span>
          <h2 className="text-3xl sm:text-4xl font-sans font-bold tracking-tight text-[#15231A] leading-tight">
            Leave with tools{' '}
            <span className="font-editorial italic font-normal text-[#005D26]">
              you can use immediately.
            </span>
          </h2>
          <p className="text-base text-[#657168]">
            Practical frameworks you can apply from Monday to upgrade your grades and student profile.
          </p>
        </div>

        {/* 4 Learning Areas Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6">
          {LEARNING_AREAS.map((item) => (
            <div
              key={item.number}
              className="p-6 sm:p-7 bg-white rounded-2xl border border-neutral-200/90 shadow-sm hover:border-[#005D26]/30 transition-colors"
            >
              <div className="flex items-center justify-between pb-3 border-b border-neutral-100 mb-4">
                <span className="font-mono text-xs font-bold tracking-wider text-[#005D26] uppercase">
                  Area {item.number}
                </span>
                <span className="text-[11px] text-[#657168] uppercase font-semibold">
                  Core Module
                </span>
              </div>

              <h3 className="text-xl font-sans font-bold text-[#15231A] tracking-tight">
                {item.title}
              </h3>

              <p className="mt-2 text-sm text-[#657168] leading-relaxed">
                {item.description}
              </p>

              <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center gap-2 text-xs">
                <span className="font-bold text-[#005D26]">Takeaway:</span>
                <span className="text-[#15231A] font-medium">{item.takeaway}</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
