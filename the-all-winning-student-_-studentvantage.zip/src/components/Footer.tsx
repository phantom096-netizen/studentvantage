import React, { useState } from 'react';
import { Mail, Shield, X, Heart } from 'lucide-react';
import { EVENT_DATA } from '../config/eventData';

interface FooterProps {
  onRegisterClick?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onRegisterClick }) => {
  const [privacyModalOpen, setPrivacyModalOpen] = useState(false);

  return (
    <footer className="bg-[#002611] text-emerald-100/70 py-16 border-t border-white/10 text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-white/10">
          
          {/* Brand Info */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <img
                src={EVENT_DATA.logoUrl}
                alt="STUDENTVANTAGE Logo"
                className="w-10 h-10 rounded-full object-cover ring-1 ring-white/20"
              />
              <span className="font-sans font-bold text-lg tracking-wider text-white uppercase">
                STUDENTVANTAGE
              </span>
            </div>

            <p className="text-sm text-emerald-100/80 leading-relaxed max-w-sm">
              <strong className="text-white block font-sans">{EVENT_DATA.name}</strong>
              {EVENT_DATA.tagline}
            </p>

            <p className="text-xs text-emerald-200/60 font-mono">
              {EVENT_DATA.dateDisplay} · {EVENT_DATA.timeDisplay}
            </p>
          </div>

          {/* Quick Nav & Event Info */}
          <div className="md:col-span-4 space-y-3">
            <span className="text-xs uppercase font-bold tracking-widest text-[#B8F36B] block">
              Event Navigation
            </span>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#about" className="hover:text-white transition-colors">
                  About the Event
                </a>
              </li>
              <li>
                <a href="#learning" className="hover:text-white transition-colors">
                  What You'll Learn
                </a>
              </li>
              <li>
                <a href="#speaker" className="hover:text-white transition-colors">
                  Speaker Spotlight
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-white transition-colors">
                  Frequently Asked Questions
                </a>
              </li>
              <li>
                <a
                  href={EVENT_DATA.registrationUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => {
                    if (onRegisterClick) {
                      e.preventDefault();
                      onRegisterClick();
                    }
                  }}
                  className="hover:text-white transition-colors text-[#B8F36B] font-semibold"
                >
                  Register for Free
                </a>
              </li>
            </ul>
          </div>

          {/* Contact & Policy */}
          <div className="md:col-span-3 space-y-3">
            <span className="text-xs uppercase font-bold tracking-widest text-[#B8F36B] block">
              Connect With Us
            </span>
            <p className="text-xs leading-relaxed">
              Have questions or inquiries regarding the webinar or student partnerships?
            </p>
            <div className="pt-1">
              <a
                href="mailto:studentvantage9@gmail.com"
                className="inline-flex items-center gap-2 text-xs text-white hover:text-[#B8F36B] transition-colors"
              >
                <Mail className="w-4 h-4 text-[#B8F36B]" />
                <span>studentvantage9@gmail.com</span>
              </a>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={() => setPrivacyModalOpen(true)}
                className="text-xs text-emerald-300 hover:text-white underline underline-offset-4 flex items-center gap-1.5"
              >
                <Shield className="w-3.5 h-3.5 text-[#B8F36B]" />
                <span>Privacy & Data Notice</span>
              </button>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-emerald-200/50">
          <p>© 2026 STUDENTVANTAGE. All rights reserved.</p>
          <div className="flex items-center gap-2 text-emerald-200/50">
            <span>Designed for ambitious university students</span>
            <span aria-hidden="true">·</span>
            <span>West Africa</span>
          </div>
        </div>

      </div>

      {/* Privacy Policy Modal */}
      {privacyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white text-[#15231A] rounded-2xl max-w-lg w-full p-6 sm:p-8 space-y-4 shadow-2xl relative border border-neutral-200">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-200">
              <h3 className="text-lg font-bold text-[#15231A] flex items-center gap-2">
                <Shield className="w-5 h-5 text-[#005D26]" />
                <span>Privacy & Registration Notice</span>
              </h3>
              <button
                onClick={() => setPrivacyModalOpen(false)}
                className="text-neutral-400 hover:text-neutral-800 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs sm:text-sm text-[#657168] leading-relaxed">
              <p>
                <strong>Information We Collect:</strong> When registering for The All-Winning Student webinar, we ask for your name, email address, tertiary institution, and level of study.
              </p>
              <p>
                <strong>How We Use It:</strong> Your details are used exclusively to deliver the Google Meet access link, webinar reminders, calendar updates, and relevant academic resources following the event.
              </p>
              <p>
                <strong>Your Trust:</strong> We respect your privacy. We never sell, rent, or distribute your email or personal information to third-party commercial entities.
              </p>
              <p>
                <strong>Questions:</strong> For inquiries regarding your registration data, contact us directly at <span className="text-[#005D26] font-medium">studentvantage9@gmail.com</span>.
              </p>
            </div>

            <div className="pt-2 text-right">
              <button
                onClick={() => setPrivacyModalOpen(false)}
                className="px-5 py-2 text-xs font-bold uppercase tracking-wider text-white bg-[#005D26] hover:bg-[#003B1A] rounded-lg transition-colors"
              >
                Understood
              </button>
            </div>
          </div>
        </div>
      )}
    </footer>
  );
};
