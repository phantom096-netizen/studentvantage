import React, { useState } from 'react';
import { CheckCircle2, MessageSquare, Download, Calendar, ExternalLink, ArrowRight, Loader2 } from 'lucide-react';
import { EVENT_DATA } from '../config/eventData';
import { registrationService } from '../services/registrationService';
import { StoredRegistration, RegistrationFormData } from '../types';
import { downloadIcsFile, getGoogleCalendarUrl } from '../utils/calendar';

interface RegistrationSectionProps {
  onRegisterClick?: () => void;
}

export const RegistrationSection: React.FC<RegistrationSectionProps> = ({ onRegisterClick }) => {
  const [formData, setFormData] = useState<RegistrationFormData>({
    fullName: '',
    email: '',
    institution: '',
    levelOfStudy: '100 Level / Year 1',
    learningQuestion: ''
  });

  const [loading, setLoading] = useState(false);
  const [activeRegistration, setActiveRegistration] = useState<StoredRegistration | null>(() => {
    return registrationService.getCurrentRegistration();
  });
  const [downloadedIcs, setDownloadedIcs] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const result = await registrationService.registerStudent(formData);
      if (result.success && result.data) {
        setActiveRegistration(result.data);
        // Automatically open the official WhatsApp registration link
        window.open(EVENT_DATA.registrationUrl, '_blank', 'noopener,noreferrer');
      }
    } catch {
      // Direct redirect fallback
      window.open(EVENT_DATA.registrationUrl, '_blank', 'noopener,noreferrer');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadCalendar = () => {
    downloadIcsFile();
    setDownloadedIcs(true);
    setTimeout(() => setDownloadedIcs(false), 3000);
  };

  return (
    <section id="register" className="py-20 bg-[#F8F7F0] border-b border-neutral-200">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {activeRegistration ? (
          /* Confirmation Pass Screen */
          <div className="bg-white rounded-3xl p-6 sm:p-10 border border-neutral-200/90 shadow-xl space-y-6 text-center animate-in fade-in duration-300">
            <div className="w-14 h-14 rounded-2xl bg-[#005D26]/10 text-[#005D26] mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h2 className="text-2xl sm:text-3xl font-sans font-bold text-[#15231A]">
                You're In!
              </h2>
              <p className="text-sm text-[#657168]">
                Your spot for <strong className="text-[#15231A]">{EVENT_DATA.name}</strong> is reserved.
              </p>
            </div>

            {/* Ticket Pass */}
            <div className="p-5 bg-[#003B1A] text-white rounded-2xl text-left border border-[#005D26]">
              <div className="flex justify-between items-center pb-4 border-b border-white/10">
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-[#B8F36B] font-bold block">STUDENT PASS</span>
                  <span className="font-bold text-base text-white">{activeRegistration.fullName}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] uppercase tracking-wider text-emerald-200/60 block">CODE</span>
                  <span className="font-mono text-xs text-[#B8F36B] font-bold">{activeRegistration.registrationCode}</span>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 pt-4 text-xs">
                <div>
                  <span className="block text-emerald-200/60 text-[10px]">DATE</span>
                  <span className="font-semibold text-white">15 Nov 2026</span>
                </div>
                <div>
                  <span className="block text-emerald-200/60 text-[10px]">TIME</span>
                  <span className="font-semibold text-white">8:00 PM WAT</span>
                </div>
                <div>
                  <span className="block text-emerald-200/60 text-[10px]">VENUE</span>
                  <span className="font-semibold text-[#B8F36B]">Google Meet</span>
                </div>
              </div>
            </div>

            {/* Direct WhatsApp CTA */}
            <div className="pt-2 space-y-3">
              <a
                href={EVENT_DATA.registrationUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-4 text-sm font-bold uppercase tracking-wider text-white bg-[#005D26] hover:bg-[#003B1A] rounded-xl transition-all shadow-md"
              >
                <MessageSquare className="w-5 h-5 text-[#B8F36B]" />
                <span>Join Official WhatsApp Group For Access Link</span>
              </a>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <button
                  onClick={handleDownloadCalendar}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#15231A] bg-[#F8F7F0] hover:bg-neutral-200 rounded-lg transition-colors border border-neutral-300"
                >
                  <Download className="w-4 h-4 text-[#005D26]" />
                  <span>{downloadedIcs ? "Calendar File Saved" : "Download .ICS File"}</span>
                </button>

                <a
                  href={getGoogleCalendarUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#15231A] bg-[#F8F7F0] hover:bg-neutral-200 rounded-lg transition-colors border border-neutral-300"
                >
                  <Calendar className="w-4 h-4 text-[#005D26]" />
                  <span>Add to Google Calendar</span>
                </a>
              </div>
            </div>
          </div>
        ) : (
          /* High-Converting Streamlined Form / Instant Register */
          <div className="bg-white rounded-3xl p-6 sm:p-10 border border-neutral-200/90 shadow-xl space-y-6">
            
            <div className="text-center space-y-2">
              <span className="text-xs font-bold uppercase tracking-widest text-[#005D26]">
                FREE 1-CLICK REGISTRATION
              </span>
              <h2 className="text-2xl sm:text-3xl font-sans font-bold text-[#15231A]">
                Reserve Your Free Seat Now
              </h2>
              <p className="text-sm text-[#657168] max-w-lg mx-auto">
                No boring lengthy forms. Click below to register directly via WhatsApp to get the direct Google Meet link.
              </p>
            </div>

            {/* Direct 1-Click WhatsApp Registration Button */}
            <div className="p-4 sm:p-6 bg-[#EAF2E9] rounded-2xl border border-[#005D26]/20 text-center space-y-3">
              <p className="text-xs font-semibold uppercase tracking-wider text-[#003B1A]">
                Fastest Option (Recommended)
              </p>
              
              <a
                href={EVENT_DATA.registrationUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={onRegisterClick}
                className="w-full inline-flex items-center justify-center gap-3 px-8 py-4 text-base font-bold uppercase tracking-wider text-white bg-[#005D26] hover:bg-[#003B1A] rounded-xl transition-all shadow-lg active:scale-98"
              >
                <MessageSquare className="w-5 h-5 text-[#B8F36B]" />
                <span>Register Instantly on WhatsApp</span>
                <ExternalLink className="w-4 h-4 text-[#B8F36B]" />
              </a>

              <p className="text-[11px] text-[#657168]">
                Instant confirmation · Google Meet link shared in group · 100% Free
              </p>
            </div>

            <div className="relative flex items-center justify-center my-4">
              <div className="border-t border-neutral-200 w-full" />
              <span className="bg-white px-3 text-xs text-[#657168] font-medium uppercase tracking-wider">
                Or fill quick details
              </span>
              <div className="border-t border-neutral-200 w-full" />
            </div>

            {/* Quick 2-Minute Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="fullName" className="block text-xs font-bold uppercase tracking-wider text-[#15231A] mb-1.5">
                    Your Name
                  </label>
                  <input
                    id="fullName"
                    name="fullName"
                    type="text"
                    required
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    placeholder="e.g. Oluwaseun Adeleke"
                    className="w-full px-3.5 py-2.5 text-sm text-[#15231A] bg-[#F8F7F0] border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#005D26] focus:bg-white transition-all"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-xs font-bold uppercase tracking-wider text-[#15231A] mb-1.5">
                    Email Address
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="name@email.com"
                    className="w-full px-3.5 py-2.5 text-sm text-[#15231A] bg-[#F8F7F0] border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#005D26] focus:bg-white transition-all"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="institution" className="block text-xs font-bold uppercase tracking-wider text-[#15231A] mb-1.5">
                  University / Tertiary Institution
                </label>
                <input
                  id="institution"
                  name="institution"
                  type="text"
                  required
                  value={formData.institution}
                  onChange={(e) => setFormData({ ...formData, institution: e.target.value })}
                  placeholder="e.g. UNILAG, Redeemer's, FUTA, UI..."
                  className="w-full px-3.5 py-2.5 text-sm text-[#15231A] bg-[#F8F7F0] border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#005D26] focus:bg-white transition-all"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-bold uppercase tracking-wider text-[#003B1A] bg-[#B8F36B] hover:bg-white hover:text-[#003B1A] border border-[#005D26]/20 rounded-xl transition-all shadow-sm active:scale-98"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Connecting...</span>
                  </>
                ) : (
                  <>
                    <span>Submit & Open WhatsApp Link</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

          </div>
        )}

      </div>
    </section>
  );
};
