import React from 'react';
import { Check, ArrowRight } from 'lucide-react';
import { AUDIENCE_PROFILES } from '../config/eventData';

interface AudienceSectionProps {
  onRegisterClick: () => void;
}

export const AudienceSection: React.FC<AudienceSectionProps> = ({ onRegisterClick }) => {
  return (
    <section className="py-16 sm:py-20 bg-[#EAF2E9] border-b border-[#005D26]/15">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="max-w-3xl space-y-4">
          <span className="text-xs sm:text-sm font-bold uppercase tracking-widest text-[#005D26]">
            WHO SHOULD ATTEND?
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-sans font-bold tracking-tight text-[#15231A] leading-[1.15] text-balance">
            This is for the student who{' '}
            <span className="font-editorial italic font-normal text-[#005D26]">
              wants more from university.
            </span>
          </h2>
          <p className="text-base sm:text-lg text-[#657168] leading-relaxed">
            Whether you are just stepping into your first year or getting ready for your final project, this session is engineered to provide clarity at every stage.
          </p>
        </div>

        {/* Clean Typographic List */}
        <div className="mt-12 space-y-4 max-w-4xl">
          {AUDIENCE_PROFILES.map((profile, index) => (
            <div
              key={index}
              className="flex items-center gap-4 p-5 sm:p-6 bg-white rounded-xl border border-neutral-200/90 shadow-sm hover:border-[#005D26]/30 transition-all duration-200"
            >
              <div className="w-8 h-8 rounded-full bg-[#005D26]/10 text-[#005D26] flex items-center justify-center shrink-0">
                <Check className="w-4 h-4 stroke-[2.5]" />
              </div>
              <p className="text-base sm:text-lg font-medium text-[#15231A]">
                {profile}
              </p>
            </div>
          ))}
        </div>

        {/* Closing Inspirational Pull Quote */}
        <div className="mt-12 p-8 sm:p-10 bg-[#003B1A] text-white rounded-2xl max-w-4xl shadow-xl border border-[#005D26]">
          <p className="font-editorial italic text-2xl sm:text-3xl text-emerald-100 leading-snug">
            "You don't have to have everything figured out. You just need to be willing to learn and take action."
          </p>
          <div className="mt-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-6 border-t border-white/10">
            <span className="text-xs uppercase tracking-wider text-[#B8F36B] font-semibold">
              Open to students across all tertiary institutions
            </span>
            <button
              onClick={onRegisterClick}
              className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-white hover:text-[#B8F36B] transition-colors"
            >
              <span>Reserve your spot today</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};
