import React from 'react';
import { ArrowDownRight, Sparkles } from 'lucide-react';
import { EVENT_DATA } from '../config/eventData';

interface FinalCTAProps {
  onRegisterClick: () => void;
}

export const FinalCTA: React.FC<FinalCTAProps> = ({ onRegisterClick }) => {
  return (
    <section className="py-24 bg-[#003B1A] text-white relative overflow-hidden border-b border-[#005D26]">
      {/* Decorative gradient overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_60%_at_50%_50%,rgba(0,132,61,0.3),rgba(0,59,26,0))] pointer-events-none" />

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
        
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-[#B8F36B]/15 text-[#B8F36B] border border-[#B8F36B]/30 tracking-wider uppercase mx-auto">
          <Sparkles className="w-3.5 h-3.5" />
          <span>JOIN HUNDREDS OF STUDENTS ACROSS INSTITUTIONS</span>
        </div>

        <h2 className="text-3xl sm:text-4xl lg:text-6xl font-sans font-bold tracking-tight text-white leading-[1.1] text-balance">
          Your university experience can be{' '}
          <span className="font-editorial italic font-normal text-[#B8F36B]">
            more intentional.
          </span>
        </h2>

        <p className="text-base sm:text-xl text-emerald-100/80 leading-relaxed max-w-2xl mx-auto">
          Learn how to approach academic excellence and build a stronger presence beyond the classroom.
        </p>

        {/* Metadata Strip */}
        <div className="pt-2 pb-4 text-xs sm:text-sm font-medium text-emerald-200/90 flex flex-wrap items-center justify-center gap-2 sm:gap-4">
          <span>{EVENT_DATA.dateDisplay}</span>
          <span className="text-[#B8F36B]">·</span>
          <span>{EVENT_DATA.timeDisplay}</span>
          <span className="text-[#B8F36B]">·</span>
          <span className="text-white font-semibold">Free Virtual Webinar on Google Meet</span>
        </div>

        <div>
          <button
            onClick={onRegisterClick}
            className="inline-flex items-center gap-2 px-10 py-5 text-base font-bold uppercase tracking-wider text-[#003B1A] bg-[#B8F36B] hover:bg-white rounded-xl transition-all duration-200 shadow-xl hover:shadow-2xl active:scale-[0.98]"
          >
            <span>Register for Free</span>
            <ArrowDownRight className="w-5 h-5 text-[#003B1A]" />
          </button>
        </div>

      </div>
    </section>
  );
};
