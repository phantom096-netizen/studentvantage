import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { EVENT_DATA } from '../config/eventData';

interface NavbarProps {
  onRegisterClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onRegisterClick }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: "About the Event", href: "#about" },
    { label: "What You'll Learn", href: "#learning" },
    { label: "Speaker", href: "#speaker" },
    { label: "FAQ", href: "#faq" },
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#003B1A]/95 backdrop-blur-md shadow-md border-b border-white/10 py-3.5'
          : 'bg-[#003B1A] py-5 border-b border-white/5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8">
          {/* Zone 1: Single element brand mark */}
          <a
            href="#"
            className="flex items-center gap-3 group text-white whitespace-nowrap shrink-0"
            aria-label="STUDENTVANTAGE Home"
          >
            <img
              src={EVENT_DATA.logoUrl}
              alt="STUDENTVANTAGE Emblem"
              className="w-9 h-9 rounded-full object-cover ring-1 ring-white/20 group-hover:ring-[#B8F36B] transition-all"
            />
            <span className="font-sans font-bold text-lg tracking-wider text-white uppercase">
              STUDENTVANTAGE
            </span>
          </a>

          {/* Zone 2: 4 single-line nav links */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-emerald-100/80">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleLinkClick(e, link.href)}
                className="hover:text-white hover:underline underline-offset-8 transition-colors whitespace-nowrap shrink-0"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="hidden md:flex items-center gap-4 shrink-0">
            <button
              onClick={onRegisterClick}
              className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-[#003B1A] bg-[#B8F36B] hover:bg-white rounded-lg transition-all duration-200 shadow-sm active:scale-95 whitespace-nowrap shrink-0"
            >
              Register for Free
            </button>
          </div>

          {/* Mobile menu trigger */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-white hover:text-[#B8F36B] focus:outline-none focus:ring-2 focus:ring-[#B8F36B] rounded-lg"
              aria-label="Toggle Navigation Menu"
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden pt-4 pb-6 border-t border-white/10 mt-3 space-y-3 animate-in fade-in slide-in-from-top-2 duration-200">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleLinkClick(e, link.href)}
                className="block px-3 py-2 text-base font-medium text-emerald-100 hover:text-[#B8F36B] hover:bg-white/5 rounded-md transition-colors"
              >
                {link.label}
              </a>
            ))}
            <div className="pt-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onRegisterClick();
                }}
                className="w-full text-center px-4 py-3 text-sm font-semibold uppercase tracking-wider text-[#003B1A] bg-[#B8F36B] hover:bg-white rounded-lg transition-colors shadow-sm"
              >
                Register for Free
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
