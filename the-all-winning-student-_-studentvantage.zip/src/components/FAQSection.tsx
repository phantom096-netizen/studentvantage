import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { FAQS } from '../config/eventData';

export const FAQSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleAccordion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-24 bg-[#F8F7F0] border-b border-neutral-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center space-y-4 mb-14">
          <span className="text-xs sm:text-sm font-bold uppercase tracking-widest text-[#005D26]">
            FREQUENTLY ASKED QUESTIONS
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-sans font-bold tracking-tight text-[#15231A]">
            Everything you need{' '}
            <span className="font-editorial italic font-normal text-[#005D26]">
              to know.
            </span>
          </h2>
          <p className="text-base text-[#657168] max-w-xl mx-auto">
            Got questions before Saturday? Find direct answers about attendance, the Google Meet format, and registration below.
          </p>
        </div>

        {/* Accordion list */}
        <div className="space-y-4">
          {FAQS.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className="bg-white rounded-2xl border border-neutral-200/90 overflow-hidden transition-all duration-200 shadow-sm"
              >
                <button
                  type="button"
                  onClick={() => toggleAccordion(index)}
                  className="w-full px-6 py-5 sm:px-8 sm:py-6 text-left flex items-center justify-between gap-4 focus:outline-none focus:ring-2 focus:ring-[#005D26]/40"
                  aria-expanded={isOpen}
                >
                  <span className="text-base sm:text-lg font-bold text-[#15231A] tracking-tight">
                    {faq.question}
                  </span>
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-all duration-200 ${
                      isOpen
                        ? 'bg-[#005D26] text-white rotate-180'
                        : 'bg-neutral-100 text-[#15231A]'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-6 pb-6 sm:px-8 sm:pb-6 text-sm sm:text-base text-[#657168] leading-relaxed border-t border-neutral-100 pt-4 animate-in fade-in duration-200">
                    <p>{faq.answer}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
