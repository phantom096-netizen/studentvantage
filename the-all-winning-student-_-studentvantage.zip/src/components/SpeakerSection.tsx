import React from 'react';
import { Award, BookOpen, CheckCircle2, MessageSquare } from 'lucide-react';
import { EVENT_DATA } from '../config/eventData';

interface SpeakerSectionProps {
  onRegisterClick?: () => void;
}

export const SpeakerSection: React.FC<SpeakerSectionProps> = ({ onRegisterClick }) => {
  return (
    <section id="speaker" className="py-20 bg-white border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl space-y-3 pb-8">
          <span className="text-xs sm:text-sm font-bold uppercase tracking-widest text-[#005D26]">
            CONFIRMED GUEST SPEAKER
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-sans font-bold tracking-tight text-[#15231A] leading-[1.15] text-balance">
            Learn from someone who{' '}
            <span className="font-editorial italic font-normal text-[#005D26]">
              walked the talk.
            </span>
          </h2>
          <p className="text-base text-[#657168]">
            Straight-to-the-point lessons from a proven academic standout on excelling in school and beyond.
          </p>
        </div>

        {/* Confirmed Speaker Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center bg-[#F8F7F0] p-6 sm:p-10 rounded-3xl border border-neutral-200/90 shadow-sm">
          
          {/* Left Column: Portrait */}
          <div className="lg:col-span-5">
            <div className="relative max-w-sm mx-auto lg:max-w-none">
              <div className="relative rounded-2xl overflow-hidden shadow-xl aspect-[3/4] bg-[#003B1A]">
                <img
                  src={EVENT_DATA.speaker.portraitUrl}
                  alt={EVENT_DATA.speaker.name}
                  className="w-full h-full object-cover object-top hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                
                {/* Scrim */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#003B1A]/85 via-transparent to-transparent" />
                
                {/* Speaker Identity Tag */}
                <div className="absolute bottom-4 left-4 right-4 p-3.5 bg-white/95 backdrop-blur-sm rounded-xl border border-white/20 shadow-md">
                  <p className="text-[11px] uppercase tracking-wider font-bold text-[#005D26]">
                    Guest Speaker
                  </p>
                  <p className="text-base font-bold text-[#15231A]">
                    {EVENT_DATA.speaker.name}
                  </p>
                  <p className="text-xs text-[#657168] font-medium">
                    {EVENT_DATA.speaker.role} · {EVENT_DATA.speaker.institution}
                  </p>
                </div>
              </div>

              {/* Confirmed Badge */}
              <div className="absolute -top-3 -right-3 bg-[#B8F36B] text-[#003B1A] font-bold text-xs px-3.5 py-1.5 rounded-full shadow-md flex items-center gap-1.5 border border-[#005D26]/20">
                <CheckCircle2 className="w-4 h-4 text-[#005D26]" />
                <span>Confirmed Speaker</span>
              </div>
            </div>
          </div>

          {/* Right Column: Key Takeaways */}
          <div className="lg:col-span-7 space-y-5">
            <div>
              <span className="text-xs uppercase tracking-widest font-bold text-[#005D26]">
                BEST GRADUATING STUDENT, REDEEMER'S UNIVERSITY
              </span>
              <h3 className="text-2xl sm:text-3xl font-sans font-bold text-[#15231A] tracking-tight mt-1">
                {EVENT_DATA.speaker.name}
              </h3>
            </div>

            <p className="font-editorial italic text-lg sm:text-xl text-[#003B1A] leading-snug">
              "{EVENT_DATA.speaker.sessionDescription}"
            </p>

            {/* Quick 3-bullet points for fast reading */}
            <div className="space-y-3 pt-2">
              <div className="flex items-start gap-3 p-3 bg-white rounded-xl border border-neutral-200/80">
                <Award className="w-5 h-5 text-[#005D26] shrink-0 mt-0.5" />
                <div className="text-sm">
                  <strong className="text-[#15231A] block">Top Exam Strategy:</strong>
                  <span className="text-[#657168]">How she prepared, revised, and consistently aced every semester.</span>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-white rounded-xl border border-neutral-200/80">
                <BookOpen className="w-5 h-5 text-[#005D26] shrink-0 mt-0.5" />
                <div className="text-sm">
                  <strong className="text-[#15231A] block">Zero-Burnout Routine:</strong>
                  <span className="text-[#657168]">Balancing heavy academic work with student leadership & personal life.</span>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-white rounded-xl border border-neutral-200/80">
                <CheckCircle2 className="w-5 h-5 text-[#005D26] shrink-0 mt-0.5" />
                <div className="text-sm">
                  <strong className="text-[#15231A] block">Live Audience Q&A:</strong>
                  <span className="text-[#657168]">Ask her your hardest university and career questions live.</span>
                </div>
              </div>
            </div>

            <div className="pt-2">
              <a
                href={EVENT_DATA.registrationUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={onRegisterClick}
                className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-bold uppercase tracking-wider text-[#003B1A] bg-[#B8F36B] hover:bg-white rounded-xl transition-all shadow-sm active:scale-95"
              >
                <MessageSquare className="w-4 h-4 text-[#003B1A]" />
                <span>Register to Join Q&A Live</span>
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
