import React from 'react';
import { ExternalLink, Users, Sparkles, Globe } from 'lucide-react';
import { EVENT_DATA } from '../config/eventData';

export const CommunitySection: React.FC = () => {
  return (
    <section className="py-20 bg-white border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="bg-[#003B1A] text-white rounded-3xl p-8 sm:p-14 border border-[#005D26] relative overflow-hidden shadow-xl">
          
          {/* Subtle background ring */}
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-[#005D26]/40 blur-2xl pointer-events-none" />

          <div className="relative grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-8 space-y-4">
              <div className="flex items-center gap-3">
                <img
                  src={EVENT_DATA.logoUrl}
                  alt="STUDENTVANTAGE"
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-[#B8F36B]/50"
                />
                <span className="text-xs font-bold tracking-widest text-[#B8F36B] uppercase">
                  THE STUDENTVANTAGE ECOSYSTEM
                </span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-sans font-bold tracking-tight text-white leading-tight">
                Your growth shouldn't end with{' '}
                <span className="font-editorial italic font-normal text-[#B8F36B]">
                  one webinar.
                </span>
              </h2>

              <p className="text-base sm:text-lg text-emerald-100/80 leading-relaxed max-w-2xl">
                STUDENTVANTAGE helps students access knowledge, skills, networks, and opportunities that support their growth beyond the classroom. We build high-value programs, curate fellowships, and bridge the gap between classroom theory and real-world leadership.
              </p>

              {/* Ecosystem Highlights */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
                <div className="flex items-center gap-2.5 text-xs text-emerald-200">
                  <Users className="w-4 h-4 text-[#B8F36B] shrink-0" />
                  <span>Pan-African Student Network</span>
                </div>
                <div className="flex items-center gap-2.5 text-xs text-emerald-200">
                  <Sparkles className="w-4 h-4 text-[#B8F36B] shrink-0" />
                  <span>Curated Opportunities</span>
                </div>
                <div className="flex items-center gap-2.5 text-xs text-emerald-200">
                  <Globe className="w-4 h-4 text-[#B8F36B] shrink-0" />
                  <span>Mentorship & Masterclasses</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-4 flex lg:justify-end">
              <a
                href="#register"
                onClick={(e) => {
                  e.preventDefault();
                  document.querySelector('#register')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="inline-flex items-center justify-center gap-2 px-8 py-4 text-sm font-bold uppercase tracking-wider text-[#003B1A] bg-[#B8F36B] hover:bg-white rounded-xl transition-all shadow-md active:scale-95 whitespace-nowrap"
              >
                <span>Discover STUDENTVANTAGE</span>
                <ExternalLink className="w-4 h-4 text-[#003B1A]" />
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
