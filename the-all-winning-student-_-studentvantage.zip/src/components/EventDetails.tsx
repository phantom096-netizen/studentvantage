import React, { useState } from 'react';
import { Calendar, Clock, Video, Award, Download, ExternalLink, Check } from 'lucide-react';
import { EVENT_DATA } from '../config/eventData';
import { downloadIcsFile, getGoogleCalendarUrl } from '../utils/calendar';

interface EventDetailsProps {
  onRegisterClick: () => void;
}

export const EventDetails: React.FC<EventDetailsProps> = ({ onRegisterClick }) => {
  const [downloaded, setDownloaded] = useState(false);

  const handleDownload = () => {
    downloadIcsFile();
    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 3000);
  };

  return (
    <section className="py-24 bg-white border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-2xl mx-auto space-y-4">
          <span className="text-xs sm:text-sm font-bold uppercase tracking-widest text-[#005D26]">
            MARK YOUR SCHEDULE
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-sans font-bold tracking-tight text-[#15231A]">
            Put it on your{' '}
            <span className="font-editorial italic font-normal text-[#005D26]">
              calendar.
            </span>
          </h2>
          <p className="text-base text-[#657168]">
            Lock in the time now so you don't miss this live opportunity to learn, ask questions, and connect.
          </p>
        </div>

        {/* 4 Details Grid */}
        <div className="mt-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          
          <div className="p-8 bg-[#F8F7F0] rounded-2xl border border-neutral-200 text-center flex flex-col items-center justify-between">
            <div className="w-12 h-12 rounded-xl bg-[#005D26]/10 text-[#005D26] flex items-center justify-center mb-4">
              <Calendar className="w-6 h-6" />
            </div>
            <div>
              <span className="block text-xs uppercase tracking-wider font-bold text-[#657168]">
                DATE
              </span>
              <p className="mt-2 text-xl font-bold text-[#15231A]">
                {EVENT_DATA.dateDisplay}
              </p>
            </div>
            <span className="mt-4 text-xs text-[#657168]">Mark the date</span>
          </div>

          <div className="p-8 bg-[#F8F7F0] rounded-2xl border border-neutral-200 text-center flex flex-col items-center justify-between">
            <div className="w-12 h-12 rounded-xl bg-[#005D26]/10 text-[#005D26] flex items-center justify-center mb-4">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <span className="block text-xs uppercase tracking-wider font-bold text-[#657168]">
                TIME
              </span>
              <p className="mt-2 text-xl font-bold text-[#15231A]">
                {EVENT_DATA.timeDisplay}
              </p>
            </div>
            <span className="mt-4 text-xs text-[#657168]">West Africa Time (WAT)</span>
          </div>

          <div className="p-8 bg-[#F8F7F0] rounded-2xl border border-neutral-200 text-center flex flex-col items-center justify-between">
            <div className="w-12 h-12 rounded-xl bg-[#005D26]/10 text-[#005D26] flex items-center justify-center mb-4">
              <Video className="w-6 h-6" />
            </div>
            <div>
              <span className="block text-xs uppercase tracking-wider font-bold text-[#657168]">
                VENUE
              </span>
              <p className="mt-2 text-xl font-bold text-[#15231A]">
                {EVENT_DATA.venue}
              </p>
            </div>
            <span className="mt-4 text-xs text-[#657168]">Access link provided on registration</span>
          </div>

          <div className="p-8 bg-[#F8F7F0] rounded-2xl border border-neutral-200 text-center flex flex-col items-center justify-between">
            <div className="w-12 h-12 rounded-xl bg-[#005D26]/10 text-[#005D26] flex items-center justify-center mb-4">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <span className="block text-xs uppercase tracking-wider font-bold text-[#657168]">
                ACCESS
              </span>
              <p className="mt-2 text-xl font-bold text-[#005D26]">
                {EVENT_DATA.access}
              </p>
            </div>
            <span className="mt-4 text-xs text-[#657168]">Zero registration fee</span>
          </div>

        </div>

        {/* Action Row: Register + Calendar Add */}
        <div className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onRegisterClick}
            className="w-full sm:w-auto px-8 py-3.5 text-sm font-bold uppercase tracking-wider text-white bg-[#005D26] hover:bg-[#003B1A] rounded-xl transition-all shadow-md active:scale-95"
          >
            Register for Free
          </button>

          <button
            onClick={handleDownload}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-[#15231A] bg-[#F8F7F0] hover:bg-neutral-200/70 border border-neutral-300 rounded-xl transition-all"
          >
            {downloaded ? (
              <>
                <Check className="w-4 h-4 text-[#005D26]" />
                <span>Downloaded .ICS File</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4 text-[#005D26]" />
                <span>Download .ICS Calendar File</span>
              </>
            )}
          </button>

          <a
            href={getGoogleCalendarUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-[#15231A] bg-[#F8F7F0] hover:bg-neutral-200/70 border border-neutral-300 rounded-xl transition-all"
          >
            <span>Add to Google Calendar</span>
            <ExternalLink className="w-4 h-4 text-[#657168]" />
          </a>
        </div>

      </div>
    </section>
  );
};
