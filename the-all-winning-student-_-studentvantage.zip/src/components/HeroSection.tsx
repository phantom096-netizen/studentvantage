import React from 'react';
import { Calendar, Clock, Video, ArrowDownRight, Award, Compass, Sparkles, CheckCircle2 } from 'lucide-react';
import { EVENT_DATA } from '../config/eventData';

interface HeroSectionProps {
  onRegisterClick: () => void;
  onExploreClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onRegisterClick,
  onExploreClick,
}) => {
  return (
    <section className="relative bg-[#003B1A] text-white pt-28 pb-20 lg:pt-36 lg:pb-28 overflow-hidden border-b border-[#005D26]">
      {/* Background ambient lighting */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_75%_65%_at_50%_-15%,rgba(0,132,61,0.32),rgba(0,59,26,0))] pointer-events-none" />
      
      {/* High-fidelity geometric background grid */}
      <div 
        className="absolute inset-0 opacity-[0.035] pointer-events-none"
        style={{
          backgroundImage: `linear-gradient(#FFFFFF 1px, transparent 1px), linear-gradient(90deg, #FFFFFF 1px, transparent 1px)`,
          backgroundSize: '40px 40px'
        }}
      />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
          
          {/* Left Column: Bold Editorial Copy & Direct CTAs */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Top Label & Free Tag */}
            <div className="flex flex-wrap items-center gap-2 sm:gap-3">
              <span className="text-xs sm:text-sm font-bold tracking-widest text-[#B8F36B] uppercase font-sans">
                {EVENT_DATA.host} PRESENTS
              </span>
              <span className="text-white/30 hidden sm:inline" aria-hidden="true">/</span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold bg-[#B8F36B]/15 text-[#B8F36B] border border-[#B8F36B]/30 tracking-wider uppercase">
                <Sparkles className="w-3 h-3 text-[#B8F36B]" />
                100% FREE VIRTUAL MASTERCLASS
              </span>
            </div>

            {/* Official Series Subtitle */}
            <div className="pt-0.5">
              <p className="text-xs sm:text-sm font-bold uppercase tracking-wider text-emerald-200/90 font-mono">
                {EVENT_DATA.name}
              </p>
            </div>

            {/* Main Display Headline with Space Grotesk + Playfair Display Italic */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-[4rem] font-sans font-bold tracking-tight text-white leading-[1.08] text-balance">
              Be more than a{' '}
              <span className="font-editorial italic font-normal text-[#B8F36B] block sm:inline">
                good student.
              </span>
            </h1>

            {/* Official Tagline */}
            <p className="text-lg sm:text-xl font-medium text-emerald-100/95 leading-snug">
              {EVENT_DATA.tagline}
            </p>

            {/* Supporting Copy */}
            <p className="text-base sm:text-lg text-emerald-100/75 leading-relaxed max-w-2xl">
              Your university experience can be about more than passing exams. Learn how to strengthen your academic performance, build your profile, and position yourself for opportunities beyond the classroom.
            </p>

            {/* Primary & Secondary CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <button
                onClick={onRegisterClick}
                className="inline-flex justify-center items-center gap-2.5 px-8 py-4 text-sm sm:text-base font-bold uppercase tracking-wider text-[#003B1A] bg-[#B8F36B] hover:bg-white rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl active:scale-[0.98] whitespace-nowrap cursor-pointer"
              >
                <span>Save My Free Spot</span>
                <ArrowDownRight className="w-5 h-5 text-[#003B1A]" />
              </button>

              <button
                onClick={onExploreClick}
                className="inline-flex justify-center items-center px-6 py-4 text-sm sm:text-base font-medium text-emerald-100 hover:text-white border border-white/20 hover:border-white/40 hover:bg-white/5 rounded-xl transition-all duration-200 whitespace-nowrap cursor-pointer"
              >
                Explore the Event
              </button>
            </div>

            {/* Event Coordinates Strip */}
            <div className="pt-6 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs sm:text-sm">
              <div className="flex items-start gap-2.5">
                <Calendar className="w-4 h-4 text-[#B8F36B] shrink-0 mt-0.5" />
                <div>
                  <span className="block text-white/50 text-[11px] uppercase tracking-wider">Date</span>
                  <span className="font-semibold text-white">Sunday, 15 Nov 2026</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-[#B8F36B] shrink-0 mt-0.5" />
                <div>
                  <span className="block text-white/50 text-[11px] uppercase tracking-wider">Time</span>
                  <span className="font-semibold text-white">8:00 PM WAT</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Video className="w-4 h-4 text-[#B8F36B] shrink-0 mt-0.5" />
                <div>
                  <span className="block text-white/50 text-[11px] uppercase tracking-wider">Venue</span>
                  <span className="font-semibold text-white">Google Meet</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Award className="w-4 h-4 text-[#B8F36B] shrink-0 mt-0.5" />
                <div>
                  <span className="block text-white/50 text-[11px] uppercase tracking-wider">Access</span>
                  <span className="font-semibold text-[#B8F36B]">100% Free</span>
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Premium Magazine-Grade Editorial Visual Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Main Visual Frame */}
              <div className="relative rounded-3xl overflow-hidden border border-white/20 bg-[#005D26]/70 shadow-2xl group">
                
                {/* Photo Layer */}
                <div className="relative aspect-[4/3] sm:aspect-[1/1] overflow-hidden">
                  <img
                    src="/src/assets/images/hero_student_editorial_1793103198776.jpg"
                    alt="African university student studying in a modern academic pavilion"
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                    referrerPolicy="no-referrer"
                  />
                  {/* Cinematic gradient scrims */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#003B1A] via-transparent to-black/20" />
                  <div className="absolute inset-0 bg-gradient-to-r from-[#003B1A]/40 via-transparent to-transparent" />
                </div>

                {/* Overlaid Header Badge: Official STUDENTVANTAGE Lockup */}
                <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                  <div className="flex items-center gap-2.5 px-3 py-1.5 bg-[#003B1A]/90 backdrop-blur-md rounded-full border border-white/20 shadow-lg">
                    <img
                      src={EVENT_DATA.logoUrl}
                      alt="STUDENTVANTAGE Emblem"
                      className="w-6 h-6 rounded-full object-cover ring-1 ring-[#B8F36B]"
                    />
                    <span className="text-[11px] font-bold tracking-wider text-white uppercase font-sans">
                      STUDENTVANTAGE
                    </span>
                  </div>

                  <span className="px-3 py-1 bg-[#B8F36B] text-[#003B1A] font-bold text-[10px] uppercase tracking-wider rounded-full shadow-md">
                    LIVE WEBINAR
                  </span>
                </div>

                {/* Overlaid Editorial Content Card on Bottom */}
                <div className="absolute bottom-4 left-4 right-4 p-4 sm:p-5 bg-[#002611]/95 backdrop-blur-md rounded-2xl border border-white/15 shadow-xl">
                  
                  <div className="flex items-center justify-between pb-3 border-b border-white/10">
                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-widest text-[#B8F36B] block">
                        THE ALL-WINNING STUDENT
                      </span>
                      <p className="font-editorial italic text-base sm:text-lg text-white font-medium">
                        "Excellence In & Out of the Lecture Hall."
                      </p>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-[10px] uppercase text-white/50 block font-mono">DATE</span>
                      <span className="font-mono text-xs font-bold text-[#B8F36B]">15 NOV 2026</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-3 text-[11px]">
                    <div className="flex items-center gap-1.5 text-emerald-100">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#B8F36B] shrink-0" />
                      <span>Academic Systems</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-emerald-100">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#B8F36B] shrink-0" />
                      <span>Profile & Fellowships</span>
                    </div>
                  </div>

                </div>

              </div>

              {/* Offset Accent Floater: Date & Time Highlight Pill */}
              <div className="hidden sm:flex absolute -bottom-4 -left-4 items-center gap-2.5 bg-white text-[#15231A] px-4 py-2.5 rounded-xl shadow-xl border border-neutral-200">
                <div className="w-2.5 h-2.5 rounded-full bg-[#005D26] animate-pulse" />
                <span className="text-xs font-bold font-sans">
                  Sunday, 15 Nov 2026 · 8:00 PM WAT
                </span>
              </div>

              {/* Offset Accent Floater Top-Right */}
              <div className="hidden sm:flex absolute -top-3 -right-3 items-center gap-2 bg-[#005D26] text-white px-3.5 py-1.5 rounded-xl shadow-lg border border-[#B8F36B]/30 text-xs font-medium">
                <Compass className="w-3.5 h-3.5 text-[#B8F36B]" />
                <span>Google Meet Access</span>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
