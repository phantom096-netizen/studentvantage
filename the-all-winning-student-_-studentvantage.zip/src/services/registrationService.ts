import { RegistrationFormData, StoredRegistration } from '../types';

const STORAGE_KEY = 'studentvantage_webinar_registrations';
const CURRENT_USER_REGISTRATION_KEY = 'studentvantage_active_registration';

export const registrationService = {
  getRegistrations(): StoredRegistration[] {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  getCurrentRegistration(): StoredRegistration | null {
    try {
      const data = localStorage.getItem(CURRENT_USER_REGISTRATION_KEY);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  },

  clearCurrentRegistration(): void {
    try {
      localStorage.removeItem(CURRENT_USER_REGISTRATION_KEY);
    } catch {
      // ignore
    }
  },

  async registerStudent(formData: RegistrationFormData): Promise<{ success: boolean; data?: StoredRegistration; error?: string }> {
    // Artificial latency for authentic loading feedback
    await new Promise((resolve) => setTimeout(resolve, 450));

    // Validation
    const cleanName = formData.fullName.trim();
    const cleanEmail = formData.email.trim().toLowerCase();
    const cleanInstitution = formData.institution.trim();
    const cleanLevel = formData.levelOfStudy.trim();

    if (!cleanName) {
      return { success: false, error: "Please enter your full name." };
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(cleanEmail)) {
      return { success: false, error: "Please enter a valid email address." };
    }

    if (!cleanInstitution) {
      return { success: false, error: "Please specify your university or institution." };
    }

    if (!cleanLevel) {
      return { success: false, error: "Please select your current level of study." };
    }

    const existing = this.getRegistrations();
    const isDuplicate = existing.some(
      (r) => r.email.toLowerCase() === cleanEmail
    );

    if (isDuplicate) {
      return {
        success: false,
        error: "This email address is already registered for The All-Winning Student. Check your inbox or reach out if you need assistance."
      };
    }

    const registrationCode = `SV-WIN-${Math.floor(1000 + Math.random() * 9000)}`;
    const newRecord: StoredRegistration = {
      id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
      registrationCode,
      fullName: cleanName,
      email: cleanEmail,
      institution: cleanInstitution,
      levelOfStudy: cleanLevel,
      learningQuestion: formData.learningQuestion?.trim() || '',
      registeredAt: new Date().toISOString()
    };

    const updated = [newRecord, ...existing];
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      localStorage.setItem(CURRENT_USER_REGISTRATION_KEY, JSON.stringify(newRecord));
    } catch (e) {
      console.warn("Storage quota exceeded or storage disabled", e);
    }

    return { success: true, data: newRecord };
  }
};
