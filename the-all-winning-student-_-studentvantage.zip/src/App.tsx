import React from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ProblemSection } from './components/ProblemSection';
import { LearningOutcomes } from './components/LearningOutcomes';
import { SpeakerSection } from './components/SpeakerSection';
import { AudienceSection } from './components/AudienceSection';
import { EventDetails } from './components/EventDetails';
import { RegistrationSection } from './components/RegistrationSection';
import { CommunitySection } from './components/CommunitySection';
import { FAQSection } from './components/FAQSection';
import { FinalCTA } from './components/FinalCTA';
import { Footer } from './components/Footer';
import { EVENT_DATA } from './config/eventData';

export const App: React.FC = () => {
  const handleRegister = () => {
    window.open(EVENT_DATA.registrationUrl, '_blank', 'noopener,noreferrer');
  };

  const scrollToAbout = () => {
    const el = document.getElementById('about');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F7F0] text-[#15231A]">
      {/* SECTION 1: NAVIGATION */}
      <Navbar onRegisterClick={handleRegister} />

      <main className="flex-1">
        {/* SECTION 2: HERO */}
        <HeroSection
          onRegisterClick={handleRegister}
          onExploreClick={scrollToAbout}
        />

        {/* SECTION 3: THE PROBLEM */}
        <ProblemSection />

        {/* SECTION 4: WHAT YOU'LL LEARN */}
        <LearningOutcomes />

        {/* SECTION 5: SPEAKER FEATURE (CONFIRMED) */}
        <SpeakerSection onRegisterClick={handleRegister} />

        {/* SECTION 6: WHO SHOULD ATTEND? */}
        <AudienceSection onRegisterClick={handleRegister} />

        {/* SECTION 7: EVENT DETAILS */}
        <EventDetails onRegisterClick={handleRegister} />

        {/* SECTION 8: REGISTRATION CALLOUT & FAST JOIN */}
        <RegistrationSection onRegisterClick={handleRegister} />

        {/* SECTION 9: COMMUNITY CONNECTION */}
        <CommunitySection />

        {/* SECTION 10: FAQ */}
        <FAQSection />

        {/* SECTION 11: FINAL CALL TO ACTION */}
        <FinalCTA onRegisterClick={handleRegister} />
      </main>

      {/* SECTION 12: FOOTER */}
      <Footer onRegisterClick={handleRegister} />
    </div>
  );
};

export default App;
