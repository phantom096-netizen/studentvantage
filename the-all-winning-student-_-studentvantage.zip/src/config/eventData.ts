import { EventConfig } from '../types';

export const EVENT_DATA: EventConfig = {
  name: "The All-Winning Student",
  tagline: "How to Excel Academically and Stand Out Beyond the Classroom.",
  dateDisplay: "Sunday, 15 November 2026",
  timeDisplay: "8:00 PM WAT",
  dateISO: "2026-11-15T20:00:00+01:00",
  durationMinutes: 60,
  venue: "Google Meet",
  access: "Completely free",
  host: "STUDENTVANTAGE",
  logoUrl: "/assets/aistudio/20260810_022659.jpg_872f998a.jpeg",
  registrationUrl: "https://wa.link/0j6qve",
  speaker: {
    name: "Oluwadamilola Alabi",
    role: "Best Graduating Student",
    institution: "Redeemer's University",
    portraitUrl: "/assets/aistudio/file_00000000865c81f48b2f9cb9419d90d2_58eca6e3.png",
    bio: "Best graduating student from Redeemer's University. She proved that academic brilliance and extracurricular impact can go hand in hand.",
    sessionDescription: "Real strategies for mastering exams, building a standout student profile, and securing big opportunities.",
    status: 'confirmed',
  }
};

export const PROBLEM_PILLARS = [
  {
    number: "01",
    title: "Smash Your Academics",
    description: "Learn proven daily study systems that turn difficult coursework into straight A's without burnout."
  },
  {
    number: "02",
    title: "Build a Standout Profile",
    description: "Go beyond grades. Build real skills, leadership, and a personal brand that companies fight for."
  },
  {
    number: "03",
    title: "Attract High-Value Opportunities",
    description: "Unlock scholarships, internships, and global fellowships before graduation."
  }
];

export const LEARNING_AREAS = [
  {
    number: "01",
    title: "Academic Excellence",
    description: "Proven routines and study systems used by top graduating students.",
    takeaway: "Master retention, semester planning, and exam execution."
  },
  {
    number: "02",
    title: "Smart Study Systems",
    description: "How to cut study time in half while retaining twice as much information.",
    takeaway: "Active recall, question banks, and weekly review workflows."
  },
  {
    number: "03",
    title: "Your Student Profile",
    description: "Why your CV and extracurricular track record matter just as much as your GPA.",
    takeaway: "Turn class projects into portfolio-worthy accomplishments."
  },
  {
    number: "04",
    title: "Landing Big Opportunities",
    description: "A step-by-step roadmap to finding and winning scholarships and internships.",
    takeaway: "Direct access to top student fellowships and talent networks."
  }
];

export const AUDIENCE_PROFILES = [
  "Students who want higher grades with less stress.",
  "Undergraduates looking to build a magnetic CV while in school.",
  "Ambitious students aiming for internships, scholarships & fellowships.",
  "Any university student ready to make their school years truly count."
];

export const FAQS = [
  {
    question: "Is this webinar 100% free?",
    answer: "Yes, completely free. No hidden fees. Register via WhatsApp to get your access link."
  },
  {
    question: "Who can attend?",
    answer: "All students across any university, polytechnic, or college in Nigeria and Africa."
  },
  {
    question: "When is the session?",
    answer: "Sunday, 15 November 2026 at 8:00 PM WAT on Google Meet."
  },
  {
    question: "Where do I get the Google Meet link?",
    answer: "Click the register button to join our official WhatsApp group where the direct link is shared."
  },
  {
    question: "How long is it?",
    answer: "60 focused minutes, including open Q&A with Oluwadamilola Alabi."
  }
];
