export function downloadIcsFile(): void {
  // Start: Sunday 15 Nov 2026 20:00 WAT (WAT is UTC+1, so UTC is 19:00)
  // End: 21:00 WAT (20:00 UTC)
  const icsContent = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//STUDENTVANTAGE//The All-Winning Student//EN',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'BEGIN:VEVENT',
    'UID:the-all-winning-student-20261115@studentvantage.org',
    'DTSTAMP:20261027T120000Z',
    'DTSTART:20261115T190000Z',
    'DTEND:20261115T200000Z',
    'SUMMARY:The All-Winning Student | STUDENTVANTAGE',
    'DESCRIPTION:How to Excel Academically and Stand Out Beyond the Classroom.\\n\\nVirtual webinar hosted by STUDENTVANTAGE.\\nVenue: Google Meet\\nAccess: 100% Free\\n\\nJoining details will be provided prior to the session.',
    'LOCATION:Google Meet',
    'STATUS:CONFIRMED',
    'TRANSP:OPAQUE',
    'BEGIN:VALARM',
    'ACTION:DISPLAY',
    'DESCRIPTION:The All-Winning Student Webinar starts in 30 minutes',
    'TRIGGER:-PT30M',
    'END:VALARM',
    'END:VEVENT',
    'END:VCALENDAR'
  ].join('\r\n');

  const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
  const url = window.URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'The_All_Winning_Student_Webinar.ics';
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  window.URL.revokeObjectURL(url);
}

export function getGoogleCalendarUrl(): string {
  const title = encodeURIComponent("The All-Winning Student | STUDENTVANTAGE");
  const details = encodeURIComponent(
    "How to Excel Academically and Stand Out Beyond the Classroom.\n\nFree virtual webinar hosted by STUDENTVANTAGE.\nVenue: Google Meet\nAccess: 100% Free"
  );
  const location = encodeURIComponent("Google Meet");
  // 15 Nov 2026 19:00 UTC to 20:00 UTC (20:00 - 21:00 WAT)
  const dates = "20261115T190000Z/20261115T200000Z";

  return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${dates}&details=${details}&location=${location}`;
}
