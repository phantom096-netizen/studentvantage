export interface SpeakerConfig {
  name: string;
  role: string;
  institution: string;
  portraitUrl: string;
  bio: string;
  sessionDescription: string;
  status: 'confirmed';
}

export interface EventConfig {
  name: string;
  tagline: string;
  dateDisplay: string;
  timeDisplay: string;
  dateISO: string;
  durationMinutes: number;
  venue: string;
  access: string;
  host: string;
  logoUrl: string;
  registrationUrl: string;
  speaker: SpeakerConfig;
}

export interface RegistrationFormData {
  fullName: string;
  email: string;
  institution: string;
  levelOfStudy: string;
  learningQuestion: string;
}

export interface StoredRegistration extends RegistrationFormData {
  id: string;
  registrationCode: string;
  registeredAt: string;
}
